import type { Page } from "@playwright/test";
import type { UiDriver } from "./UiDriver";

export class PlaywrightUiDriver implements UiDriver {
  public constructor(private readonly page: Page) {}

  async click(selector: string): Promise<void> {
    await this.page.locator(selector).click();
  }

  async fill(selector: string, value: string): Promise<void> {
    await this.page.locator(selector).fill(value);
  }

  async getText(selector: string): Promise<string> {
    return (await this.page.locator(selector).textContent()) ?? "";
  }

  async navigate(url: string): Promise<void> {
    await this.page.goto(url);
  }
}
