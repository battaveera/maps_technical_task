import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { CalculateHolidayEntitlementPage } from "../pages/CalculateHolidayEntitlementPage";

test.describe("Holiday Entitlement Calculator Home Page - Accessibility Test", () => {
  test("Validate home page accessibility", async ({ page }) => {
    const homePage = new CalculateHolidayEntitlementPage(page);
    await homePage.navigate();
    await homePage.expectHomePageElements();

    const accessibilityResults = await new AxeBuilder({ page }).analyze();

    expect(accessibilityResults.violations).toEqual([]);
  });
});
